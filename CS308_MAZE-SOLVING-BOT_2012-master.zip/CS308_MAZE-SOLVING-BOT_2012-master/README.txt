2012 - CS308  Group 18 : Project MAZE SOLVING BOT
================================================

Group Info:
------------
+   Bhuvan teja (09005049)
+   Varun suprasanth (09005063)
+   Pathan Salman Khan (09005064)
+   Asok R. (09005072)

Extension Of
------------

It is a new project. It is not an extension of any existing project. 

Project Description
-------------------

Our project is basically programming a bot such that it solves a maze automatically. That is, given a maze, a start point and an end point, it will first explore the maze, reach the end point, and then trace back to start point in the optimal path. This is done by employing three algorithms, namely A-star, Tremaux and wall follower.  

Setting up and running : 
To run code on robot, the codes from the folder "Code for robot" is used.
To run code on player stage, the codes from the folder "Code for player stage" is used.
To run latter, player stage needs to be installed on the machine.(Installation instructions given below).

Technologies Used
-------------------

Remove the items that do no apply to your project and keep the remaining ones.

+   Embedded C


Installation Instructions
=========================

Player stage installation is required. Link: http://playerstage.sourceforge.net/


References
===========

Please give references to importance resources. 

+ [Title](http://playerstage.sourceforge.net/)
